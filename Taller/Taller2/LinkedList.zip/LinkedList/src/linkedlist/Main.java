package linkedlist;

import java.util.Iterator;

/**
 *
 * Profesora: Adriana Collaguazo Jaramillo
 */
public class Main {
    
    @SuppressWarnings("empty-statement")
    public static void main (String[] args)
    {
        
        //int[] valor = new int[700];
        
        List<Integer> l1= new ArrayList<>();
        l1.addFirst(1);
        l1.addFirst(2);
        l1.addFirst(3);
        l1.addFirst(4);
        
        List<Integer> list1 = new LinkedList<>();
        List<Integer> list2 = new LinkedList<>();
        
        List<Integer> list= new ArrayList<>();
        list.addLast(1);
        list.addLast(2);
        list.addLast(3);
        list.addLast(4);
        
        //Iterator<Integer> it=list.iterator();
        
        //Equivalencias
        for (Integer n : list){
            System.out.println(n);
        }
        
        Iterator<Integer> it=list.iterator();
        while(it.hasNext()){
            Integer n = it.next();
            System.out.println(n);
        }
        
        //List<Double> l3 = new LinkedList<>();
        
        // l1.addFirst(10);
        // l1.addFirst(20);
        // l1.addFirst(30);

        //for (int i = 0; i < l1.size(); i++) {
        //    System.out.println(l1.get(i));
        
        // Ejemplo: Estrategia para recorrer los elementos del ArrayList de Java
        java.util.ArrayList<Integer> tmp = new java.util.ArrayList<>();
        
        tmp.add(1);
        tmp.add(2);
        tmp.add(3);
        tmp.add(4);
        
        for (int i=0; i<tmp.size(); i++){
               System.out.println(tmp.get(i));
        }
        
        // Otra estrategia para recorrer los elementos del ArrayList sin usar índices es el método Iterator
        // retorna una variable de tipo Iiterator
        Iterator<Integer> it=tmp.iterator();
        while(it.hasNext()){  
            Integer n=it.next();
            System.out.println(n);
        }
        
        // Simulación de foreach
        for(Integer n : tmp){
            System.out.println(n);
        
        }
        
        Iterator<Integer> it2=l1.iterator();
        while(it2.hasNext()){  
            Integer n=it2.next();
            System.out.println(n);
        }
        
        for(Integer n : l1){
            System.out.println(n);
        }
    }
}
